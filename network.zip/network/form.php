<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/stye/css/form.css">
    <title>login</title>
</head>
<body>
<h1>login</h1>
<form method="post">
    <label for="username">username:</label>
    <input type="text" id="username" name="username" required>

    <label for="password"> password:</label>
    <input type="password" id="password" name="password" required>

    <label for="password">check password:</label>
    <input type="password" id="password" name="checkpassword" required>
    <input type="submit" value="Login">
</form> 
</body>
<?php
//get data with form
if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['checkpassword'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $checkpassword = $_POST['checkpassword'];
    // admin username
    $user = "dark code";
    // admin password
    $UserPassword = "dark";

    // Data validation
    if(empty($username) || empty($password) || empty($checkpassword)){
        echo "<div class='error'><h2>Fill the input </h2></div>";
    }elseif($password != $checkpassword){
        echo"<div class='error'><h2>please enter your password again </h2></div>\n";
    }
    if($password < 6 ){
        echo "<div class='error'><h2>Password must be greater than 6 </h2></div>\n";
    }
    if($username != $user || $password != $UserPassword){
        echo " <div class='error'><h2>please try again</h2></div>\n";
    }else{
        // start session
        session_start();
        $sessionID = session_id();
        //save data session
        // file_put_contents($files, $sessionID);
        // get date and time
        $date = date('Y-m-d H:i:s');
        // get ip 
        $ip = $_SERVER['REMOTE_ADDR'];
        // get file name
        $self = $_SERVER['PHP_SELF'];
        // get server
        $servername =  $_SERVER['SERVER_NAME'];
        // get host name
        $host = $_SERVER['HTTP_HOST'];
        // get server linki
        $refer =  $_SERVER['HTTP_REFERER'];
        // get script name
        $script =  $_SERVER['SCRIPT_NAME'];
        // get requesr method
        $request =  $_SERVER['REQUEST_METHOD'];
        // get requesr url 
        $url =  $_SERVER['REQUEST_URI'];
        // get query
        $string =  $_SERVER['QUERY_STRING'];
        // creat and save file in folder 
        $fileName = "user/" . "user_" . uniqid() . ".txt";
        // session 

        // save data in folder and file
        $fileContent .= "username: {$username}\n";
        $fileContent .= "password: {$password}\n";
        $fileContent .= "sessionID: {$sessionID}\n";
        $fileContent .= "date: {$date}\n";
        $fileContent .= "IP: {$ip}\n";
        $fileContent .= "PHP_SELF: {$self}\n";
        $fileContent .= "SERVER_NAME: {$servername}\n";
        $fileContent .= "HTTP_HOST: {$host}\n";
        $fileContent .= "HTTP_REFERER: {$refer}\n";
        $fileContent .= "SCRIPT_NAME: {$script}\n";
        $fileContent .= "REQUEST_METHOD: {$request}\n";
        $fileContent .= "REQUEST_URI: {$url}\n";
        $fileContent .= "QUERY_STRING: {Null} {$string}";
        // get data in folder and file
        file_put_contents($fileName, $fileContent);

        echo "<div class='error' <h1> you are login <a href='/index.php' title='messager page'>Click to login</a></h1></div>";

        // end the operation
        exit; 
    }
}else{
    echo "<div class='error'><h2>please do all Fill</h2></div>";
}
?>
</html>