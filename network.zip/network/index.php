<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Haker messager</title>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Rubik:300,300i,400,400i,500,500i,700,700i,900,900i' type='text/css'>
  <link rel="stylesheet" href="/stye/css/style.css">
  <script src="https://kit.fontawesome.com/your-font-awesome-kit.js" crossorigin="anonymous"></script>
</head>
<body>
  <div class="messenger">
    <div class="messenger-header">
      <h1>hacker messager</h1> <img src="img/4198318.webp" alt="Avatar">
    </div>
    <a href=""><img src="/img/icons8-user-50.png" alt="user" class="user" title="userInfo"></a>
    <a href="http://localhost:8002/form.php"><img src="/img/icons8-logout-50.png" alt="log-out" title="log-out" class="log-out" target="_blank""></a>
    <div class="messenger-body">
      <div class="messenger-chat">
        <div class="messenger-chat-header">
          <h2>Chat</h2>
        </div>
        <div id="messenger-chat-messages">
          <?php
          //get data with form
          if(isset($_POST['messageInput'])) {
            $message = $_POST['messageInput'];
            //creat file
            $file = fopen('messages.txt', 'a');
            // write chat in file
            fwrite($file, $message . PHP_EOL);
            fclose($file);
          }
          //Read data from file
          $messages = file_get_contents('messages.txt');
          $messagesArray = explode(PHP_EOL, $messages);
          // echo data
          foreach($messagesArray as $message) {
            $class = '';
            if (strpos($message, 'خر') !== false) {
              $class = 'green';
            } elseif (strpos($message, 'دیگه') !== false) {
              $class = 'blue';
            }
            echo "<div class='messenger-chat-message'>";
            echo "<div class='messenger-chat-message-sender'>" . $date = date('Y-m-d H:i:s');
            echo "<p></p>";
            echo "</div>";
            echo "<div class='messenger-chat-message-text $class'>";
            echo "<p>" . $message . "</p>";
            echo "</div>";
            echo "</div>";
          }
          ?>
        </div>
        <div class="messenger-chat-input">
          <form method="POST" action="">
            <div class="messenger-chat-input">
            <input type="text" placeholder="Type your message..." name="messageInput" id="messageInput">
            <button type="submit"><i class="fas fa-paper-plane"></i></button>
        </div>
          </form>
        </div>
      </div>
      <div class="messenger-contacts">
        <div class="messenger-contacts-header">
          <h2>Contacts</h2>
        </div>
        <div class="messenger-contacts-list">
          <div class="messenger-contacts-item">
            <div class="messenger-contacts-item-avatar">
              <img src="img/4198318.webp" alt="Avatar">
            </div>
            <div class="messenger-contacts-item-name">
              <?php
              $ip = $_SERVER ['REMOTE_ADDR'];
              echo "<p>$ip</p>";
              ?>
            </div>
          </div>
          <div class="messenger-contacts-item">
            <div class="messenger-contacts-item-avatar">
              <img src="img/5341357.png" alt="Avatar">
            </div>
            <div class="messenger-contacts-item-name">
              <?php
              echo "<p>170.0.1.1</p>";
              ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="script.js"></script>
</body>
</html>