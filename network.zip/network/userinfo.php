<!DOCTYPE html>
<html>
<head>
  <title>userinfo</title>
  <style>
    body {
        background: url(img/hacker-jacket-with-hood-with-laptop-sits-table_164357-56.avif);
        background-size: cover;
      color: #0f0;
      font-family: "Courier New", monospace;
      text-align: center;
    }
    .hacker-image {
      width: 200px;
      height: 200px;
      object-fit: cover;
      border: 2px solid #0f0;
      border-radius: 50%;
      margin: 20px auto;
    }
    .hacker-info {
      font-size: 24px;
      margin-bottom: 20px;
    }
    .hacker-info p {
      margin: 10px 0;
    }
  </style>
</head>
<body>
  <img src="/img/4198318.webp" alt="تصویر هکر" class="hacker-image">
  <div class="hacker-info">
    <h1>mike</h1>
    <p>age:20</p>
    <p>country:USA</p>
    <p>City:NewYork</p>
  </div>
  <div>
    <?php
    // echo ip
    $ip = $_SERVER['REMOTE_ADDR'];
    echo "<h2>ip: $ip</h2>";
    ?>
    
  </div>
</body>
</html>